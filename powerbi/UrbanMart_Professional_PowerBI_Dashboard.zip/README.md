# UrbanMart Retail Analytics — Power BI project

**Power BI editable project (PBIP) + an independent offline interactive preview.**

## Open the Power BI report

1. Unzip the archive fully to a Windows folder.
2. Open **UrbanMart_Retail_Analytics.pbip** with a current version of **Power BI Desktop**.
3. Wait for the model to load; if the page visuals appear blank, use **Home → Refresh** once. Both source CSVs are embedded as compressed, local Power Query data, so no database connection or path changes are required.
4. To apply UrbanMart colors: **View → Themes → Browse for themes → UrbanMart_Theme.json**.
5. In **File → Save As** choose **Power BI report (.pbix)** if you need a single PBIX file.

> **Compatibility note:** The PBIP text project and PBIR visuals were generated programmatically and syntax-checked. A live Power BI Desktop open/refresh was not available in this environment; Desktop may request compatibility repairs. If that happens, use the provided DAX and layout reference and the preview, and share the Desktop error for a targeted fix.

## Dashboard pages

- **01 Executive Overview:** headline KPIs, monthly revenue, sales categories, store-city revenue, payment split.
- **02 Product & Profitability:** top products, product-level margin, discount rate, low-stock products.
- **03 Customers & Stores:** customer volume/value, city revenue, payment modes, customer leaderboard.

## Data model

```
Products[product_id]  1 ────────── *  Sales[product_id]
```

**6,000 sales transactions and 90 products** for calendar year 2025. Two import tables, one single-direction relationship. `month_start` has been added to Sales for clean monthly charting. Original source columns are preserved.

## Metric definitions

- **Net Revenue** = sum of recorded `net_amount` (₹17,509,696.59).
- **Estimated COGS** = sum of `quantity × Products[cost_price]`. This is an analytical estimate, not booked cost of goods sold.
- **Estimated Gross Profit** = Net Revenue minus Estimated COGS (estimated COGS: ₹11,959,308.14).
- **Margin** = Estimated Gross Profit / Net Revenue.
- **Transactions** = distinct transaction IDs; **Customers** = distinct customer IDs.
- **Discount Rate** = recorded discounts / pre-discount gross sales.
- **Low-stock** = current `stock_quantity <= reorder_level` (an inventory snapshot; not historical stock during 2025).

No forecast or machine-learning claims are made. There is one year of sales, so year-over-year metrics are intentionally omitted.

## Contents

```
UrbanMart_Retail_Analytics.pbip
UrbanMart_Retail_Analytics.Report/       # PBIR: 3 pages and editable visuals
UrbanMart_Retail_Analytics.SemanticModel/ # TMDL measures, data imports, relationship
UrbanMart_Theme.json                     # color palette
DAX_Measures.txt                         # editable reusable formulas
data/products.csv
data/sales_transactions.csv
```

The accompanying `UrbanMart_Dashboard_Preview.html` is a **standalone interactive browser preview**, not a Power BI `.pbix` file.

## Preview screenshots

The `screenshots/` images show the validated **standalone HTML dashboard**, not a render from Power BI Desktop. The `.pbip` project must be opened and checked in Power BI Desktop before sharing a PBIX screenshot.
